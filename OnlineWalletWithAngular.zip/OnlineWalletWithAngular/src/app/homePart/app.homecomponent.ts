import { Component} from '@angular/core';

@Component({
    selector: 'home',
    templateUrl: 'app.homecomponent.html',
    styleUrls:["./app.homepagecomponent.css"]
})
/**
	 *author: Venkatesh 
	 *created Date: 20/10/2019
	 *last modified : 20/10/2019            
	 */
export class homePage{
}