export class WalletUser{
    userName:string
    userPassword:string;
    phoneNo:string;
}